/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QuanLyBaiTapNhom1;

import java.util.*;
/**
 *
 * @author Administrator
 */
public class DanhSach {
    protected ArrayList<SinhVien> a;

    public DanhSach() {
        this.a = new ArrayList<SinhVien>();
    }

    public ArrayList<SinhVien> getA() {
        return a;
    }
    
    
}
